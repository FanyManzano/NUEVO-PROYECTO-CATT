/* 
  var : variable GLOBAL, SI puede cambiar su valor a lo largo de su trayecto 
  let:  variable LOCAL, SI puede cambiar su valor a lo largo de su trayecto
  const: variable LOCAL, NO puede cambiar su valor a lo largo de su trayecto

  undefined: se quiere mostrar una variable que no esta definida o en su 
  caso no esta siendo inicializada

  NaN: se quiere multiplicar un valor umerico por una cadena o algo distinto 
  a un número.
*/

/*La página enviando un mensaje*/
let mensaje = "Hola soy un mensaje de prueba";
alert(mensaje);

/* Capturando una cadena escrita por el usuario, con PROMPT() */
let cadena;
cadena = prompt("Introduce tu nombre:");
alert(cadena);


/* Escribiendo sobre el documento con document.write */

let mensajito = "hola soy un mensajito";
document.write(mensajito);

