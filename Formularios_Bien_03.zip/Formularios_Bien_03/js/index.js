
    function scroll_izq(){
        
        let izquierda = document.querySelector(".scroll-img");
        izquierda.scrollBy(350,0);
    }

    function scroll_der(){
    
        let derecha = document.querySelector(".scroll-img");
        derecha.scrollBy(-350,0);
        
    }