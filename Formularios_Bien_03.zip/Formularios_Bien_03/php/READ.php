<?php 
/******** READ ********/

/*1.Conectando a la Base de datos*/
$conexión = mysqli_connect("localhost","root","","catt");
/*2.Query sql*/
$query = "SELECT * FROM Alumno";
/*3.Ejecutando la Query*/
$respuesta = mysqli_query($conexión,$query);
/*4.Mostrando respuesta de la query*/
// Opción a) var_dump($respuesta);
// Opción b) echo mysqli_num_rows($respuesta);

/* Filas afectadas por la consulta */
while($fila = mysqli_fetch_row($respuesta))
{
    echo $fila[0]." ".$fila[4]." ".$fila[5]."<br>";  
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>READ</title>
<meta name='viewport' content='width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no'/>
<link href="" rel="stylesheet">
</head>
<body>
    
</body>
</html>