<?php

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $id = $_POST["boleta"];
    $nombre = $_POST["nombre"];
    $apellido_01 = $_POST["apellido_01"];
    $apellido_02 = $_POST["apellido_02"];
    $correo = $_POST["correo"];
    $tel = $_POST["tel"];
    $contrasena = $_POST["contrasenia_02"];
    $radio = $_POST["radio"];

    /* Ocultación de contraseña */
    $contrasena_O = MD5($contrasena);

    if (isset($_POST["radio"]) && $_POST["radio"]=="alumno") echo "checked";
    if (isset($_POST["radio"]) && $_POST["radio"]=="representante") echo "checked";

    /* 1.Conexión a la base */
    $puerto = "localhost";
    $usuario = "root";
    $clave = "";
    $bd = "catt";
    $conexion = mysqli_connect($puerto,$usuario,$clave,$bd);

    /* Comprueba la conexión */
    if (mysqli_connect_errno()) {
        printf("LA CONEXIÓN A FALLLADO %s\n", mysqli_connect_error());
        exit();
    }

    /* 2. Query sql */
    $q = "INSERT INTO profesor VALUES(
        '$id',
        '$nombre',
        '$apellido_01',
        '$apellido_02',     
        '$correo',
        '$tel',
        '$radio[0]',
        '$contrasena_O',
        NOW())";

    /* Estructura para no cortar flujo del programa
    al encontrar excepciones */       
    try{
        /* 3. Ejecutando la query */
        $exec_query = mysqli_query($conexion,$q);
    }catch(Exception $ex){ } 

    /*4. Filas afectadas por la query*/
    $respuesta_query = mysqli_affected_rows($conexion);
    if($respuesta_query == 1){

        echo "USUARIO REGISTRADO CORRECTAMENTE";
        /*Redireccionando hacia otra página*/
       // header("Location: ../html/loginAlumno.html");
        echo "<script> Swal.fire(
            'Good job!',
            'You clicked the button!',
            'success');</script>";
    }else{
        echo "<br>ERROR. FAVOR DE INTENTARLO NUEVAMENTE";
    }

    /* Cerrando conexión */
    mysqli_close($conexion);
}

?>

<?php

    /* 1.Conexión a la base */
    $puerto = "localhost";
    $usuario = "root";
    $clave = "";
    $bd = "catt";
    $conexion = mysqli_connect($puerto,$usuario,$clave,$bd);

    /* 2. Query sql */
    $q_01 = "SELECT * FROM profesor ORDER BY id_profesor DESC LIMIT 1";

    /* Estructura para no cortar flujo del programa al encontrar excepciones */       
    try{
        /* 3. Ejecutando la query */
        $exec_query01 = mysqli_query($conexion,$q_01);
    }catch(Exception $ex){ } 
     /*4. Filas afectadas por la query*/
    $respuesta_query01 = mysqli_fetch_array($exec_query01);
    $ultimoId = $respuesta_query01['id_profesor'];
    $profId = $ultimoId + 1;

 /* En caso de quue implique una cadena   
 if7($ultimoId == " "){
        $profId = 1;
    7}else{
        $profId = substr($ultimoId,3);
        $profId = intval($profId);
        $profId = $profId + 1;
    }
   */
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Registro Profesor</title>
<meta name='viewport' content='width=device-width,initial-scale=1,minimum-scale=1,
maximum-scale=1,user-scalable=no'/>
<meta name="description" content="">
<meta name="keywords" content="">
<!--Incluyendo validetta a nuestro form-->
<link href="../validetta-1.0.1/dist/validetta.css" rel="stylesheet">
<script src="../validetta-1.0.1/jQuery v3.6.0.js"></script>
<script src="../validetta-1.0.1/dist/validetta.js"></script>
<script src="../validetta-1.0.1/localization/validettaLang-es-ES.js"></script>
<!--Incluyendo bootstrap-->
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css"
 rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" 
 crossorigin="anonymous">
 <!--Incluyendo SweetAlert-->
 <link href="../sweetAlert/dist/sweetalert2.css" rel="stylesheet">

<script>
  $(document).ready(()=>{ 
      $("#form_1").validetta();
  });
</script>
</head>
<body>
    <!--Ligar con php-->
    <form name="Profesor" id="form_1" action="<?php echo($_SERVER["PHP_SELF"]);?>" method="post"> 
        <fieldset>
         <legend> Registro Profesor</legend>
         <!-- Boleta generada automaticamente-->
         Boleta: <input type="text" size="10" name="boleta" id="id" value="<?php echo $profId; ?>" 
         readonly data-validetta="number"/>
         <br/><br/>
         Nombre: <input type="text" size="20" name="nombre" 
         data-validetta="required,regExp[regExp[^0-9],maxLength[20]"/> 
         <br/><br/>
         Primer Apellido: <input type="text" size="20" name="apellido_01"
         data-validetta="required,regExp[[a-z]*],maxLength[20]"/>
         <br/><br/>
         Segundo Apellido: <input type="text" size="20" name="apellido_02"
         data-validetta="required,regExp[[a-z]*],maxLength[20]"/>
         <br/><br/>
         Correo: <input type="text" size="30" name="correo"
         data-validetta="required,email"/>
         <br/><br/>
         Telefono: <input type="text" size="10" name="tel"
         data-validetta="required,number,minLength[10]"/>
         <br/><br/>
         Contraseña: <input type="password" size="32" name="contrasenia_01"
         data-validetta="required,minLength[8],maxLength[32]"/>
         <br/><br/>
         Repetir contraseña: <input type="password" size="32" name="contrasenia_02"
         data-validetta="required,minLength[8],maxLength[32],equalTo[contrasenia_01]"/>
         <br/><br/>
         <!-- Se identifica con 0 si es EXTERNO -->
         <input type="radio" name="radio[]"  value="0">
         <label for="EXTERNO">Externo</label>
         <br/><br/>
         <!-- Se identifica con 1 si es de ESCOM-->
         <input type="radio" name="radio[]"  value="1">
         <label for="Perteneciente a ESCOM">Perteneciente a ESCOM</label>
         <br/><br/>
         <button type="submit" class="btn btn-success">
           Enviar
         </button>
        </fieldset>
      </form>

 <!-- JavaScript Bundle with Popper <<Bootstrap>> -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"
 integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" 
 crossorigin="anonymous"></script>
 <!--Incluyendo SweetAlert-->
 <script src="../sweetAlert/dist/sweetalert2.all.js" ></script>
</body>
</html>