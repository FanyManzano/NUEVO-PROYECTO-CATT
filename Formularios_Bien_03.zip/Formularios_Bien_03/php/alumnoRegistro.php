<?php
$boleta = $_POST["boleta"];
$nombre = $_POST["nombre"];
$apelllido_01 = $_POST["apellido_01"];
$apellido_02 = $_POST["apellido_02"];
$correo = $_POST["correo"];
$telefono = $_POST["telefono"];
$contrasenia_01 = $_POST["contrasenia_01"];
$contrasenia_02 = $_POST["contrasenia_02"]; //creo que esta variable esta de más 
$radio = $_POST["radio"];

/* Ocultación de contraseña */
$ocultacion = MD5($contrasenia_01);

if (isset($_POST["radio"]) && $_POST["radio"]=="alumno") echo "checked";
if (isset($_POST["radio"]) && $_POST["radio"]=="representante") echo "checked";


/*1.Conectando a la Base de datos*/
$conexion = mysqli_connect("localhost","root","","catt");

/* Comprueba la conexión */
if (mysqli_connect_errno()) {
    printf("LA CONEXIÓN A FALLLADO %s\n", mysqli_connect_error());
    exit();
}


/******** INSERT INTO ********/
/*2.Query sql*/
$query = "INSERT INTO Alumno VALUES(
    '$boleta',
    '$nombre',
    '$apelllido_01',
    '$apellido_02',
    '$correo',
    '$telefono',
    '$radio[0]',
    '$ocultacion',
     NOW())";
/*3.Ejecutando la Query*/
$respuesta = mysqli_query($conexion,$query);
/*4. Filas afectadas por la query*/
$filas = mysqli_affected_rows($conexion);
if($filas == 1){
    echo "USUARIO REGISTRADO CORRECTAMENTE <br>";
}else{
    echo "ERROR. FAVOR DE INTENTARLO NUEVAMENTE <br>";
}

/* Cerrando conexión */
mysqli_close($conexion);
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Formulario-alumnos</title>
<meta name='viewport' content='width=device-width,initial-scale=1,minimum-scale=1,
maximum-scale=1,user-scalable=no'/>
<meta name="description" content="">
<meta name="keywords" content="">
<link href="" rel="stylesheet">
</head>
<body>
<?php
       echo $boleta."<br>".
        $nombre."<br>".
        $apelllido_01."<br>".
        $apellido_02."<br>".
        $correo."<br>".
        $telefono."<br>".
        $contrasenia_01."<br>".
        $contrasenia_02."<br>".
        $radio[0];
    ?>
</body>
</html>