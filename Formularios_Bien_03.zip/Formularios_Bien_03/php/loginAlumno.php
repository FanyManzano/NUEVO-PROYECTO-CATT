<?php

  $usuario = $_POST["usuario"];
  $contrasena = $_POST["contrasena"];
  
    /*1.Conectando a la Base de datos*/
    $conexion_02= mysqli_connect("localhost","root","","catt");
    /*2.Query's sql*/
    $query_01 = "SELECT COUNT(*) boleta FROM Alumno WHERE representante = 1";
    $query_02 = "SELECT boleta FROM Alumno WHERE representante = 1";
    $query_03 = "SELECT ";
    /*3.Ejecutando la Query's*/
    $respuesta_01 = mysqli_query($conexion_02,$query_01);
    $respuesta_02 = mysqli_query($conexion_02,$query_02);
    $Validar_Representante = 0; // Contador de representantes

    /*4. Filas leidas por la query*/
    while($filas_02 = mysqli_fetch_row($respuesta_02)){
      //echo $filas_02[0]."<br>";   //boletas de los representantes
      /*Comparando respuesta de query con $usuario de login para dar acceso*/
      if($filas_02[0]==$usuario){
        //  if( == $contrasena){ 
            header("Location: ../html/index.html");
          //} 
      }else{
            $Validar_Representante++;
      }
    }
    $filas_01 = mysqli_fetch_row($respuesta_01); //cantidad de representantes
    if($Validar_Representante == $filas_01[0]){
      //echo $filas_01[0]."<br>";
      echo "ERROR. ACCESO DENEGADO <br>";         
    }

    /* Cerrando conexión */
    mysqli_close($conexion_02);
?>